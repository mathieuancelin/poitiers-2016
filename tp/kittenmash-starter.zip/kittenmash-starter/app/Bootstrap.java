import play.*;
import play.jobs.*;
import play.test.*;

import models.*;

import java.util.List;
import java.io.File;

@OnApplicationStart
public class Bootstrap extends Job {
    public void doJob() {
    	if (Kitten.count() > 0) { Kitten.deleteAll(); }
        File root = new File(play.Play.applicationPath + "/public/images/kittens");
        for (File img : root.listFiles()) {
        	Kitten kitten = new Kitten("public/images/kittens/"
                + img.getName()).save();
        }
    }
}
