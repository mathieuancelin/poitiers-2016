package models;

import play.db.jpa.Model;

import javax.persistence.Entity;
import java.util.Random;

@Entity
public class Kitten extends Model {

    public String url;

    public Kitten(String url) {
        this.url = url;
    }
}
