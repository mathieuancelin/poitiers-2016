package controllers;

import play.mvc.*;

import models.*;

import java.util.*;

public class Application extends Controller {
    public static void index() {
        render();
    }
}
